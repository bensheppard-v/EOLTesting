"""Voyant API - Python bindings for Voyant point cloud data and services."""

# Import the native extension module first (this loads the Rust code)
from .voyant_api import VoyantFrame
from .voyant_api import VoyantPlayback
from .voyant_api import VoyantClient
from .voyant_api import VoyantRecorder
from .voyant_api import RecordStatus
from .voyant_api import init_voyant_logging
from .voyant_api import create_default_frame
from .voyant_api import create_test_frame
from . import utils
# from .voyant_api import protos, playback, client

__version__ = "0.3.5"
__all__ = [
    "VoyantFrame",
    "VoyantPlayback",
    "VoyantClient",
    "VoyantRecorder",
    "RecordStatus",
    "init_voyant_logging",
    "create_default_frame",
    "create_test_frame",
    # "protos",
    # "playback",
    # "client",
    "utils",
]
