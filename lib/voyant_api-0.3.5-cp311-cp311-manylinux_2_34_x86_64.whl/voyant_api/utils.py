"""Utilities for working with VoyantFrame data."""

import pandas as pd
from .voyant_api import VoyantFrame


def frame_to_xyz_dataframe(
    frame: VoyantFrame, valid_only: bool = False
) -> pd.DataFrame:
    """Convert VoyantFrame XYZ data to pandas DataFrame.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points

    Returns:
        pandas DataFrame with x, y, z columns
    """

    if valid_only:
        data = frame.valid_xyz()
    else:
        data = frame.xyz()

    return pd.DataFrame(data, columns=frame.xyz_columns())


def frame_to_xyzv_dataframe(
    frame: VoyantFrame, valid_only: bool = False
) -> pd.DataFrame:
    """Convert VoyantFrame XYZV data to pandas DataFrame.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points

    Returns:
        pandas DataFrame with x, y, z, radial_vel columns
    """

    if valid_only:
        data = frame.valid_xyzv()
    else:
        data = frame.xyzv()

    return pd.DataFrame(data, columns=frame.xyzv_columns())


def frame_to_spherical_dataframe(
    frame: VoyantFrame, valid_only: bool = False, degrees: bool = False
) -> pd.DataFrame:
    """Convert VoyantFrame spherical data to pandas DataFrame.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points
        degrees: If True, angles in degrees; if False, angles in radians

    Returns:
        pandas DataFrame with range, azimuth, elevation columns
    """

    if valid_only:
        data = frame.valid_spherical(degrees=degrees)
    else:
        data = frame.spherical(degrees=degrees)

    return pd.DataFrame(data, columns=frame.spherical_columns())


def frame_to_spherical_v_dataframe(
    frame: VoyantFrame, valid_only: bool = False, degrees: bool = False
) -> pd.DataFrame:
    """Convert VoyantFrame spherical + velocity data to pandas DataFrame.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points
        degrees: If True, angles in degrees; if False, angles in radians

    Returns:
        pandas DataFrame with range, azimuth, elevation, radial_vel columns
    """

    if valid_only:
        data = frame.valid_spherical_v(degrees=degrees)
    else:
        data = frame.spherical_v(degrees=degrees)

    return pd.DataFrame(data, columns=frame.spherical_v_columns())


def frame_to_dataframe(frame: VoyantFrame, valid_only: bool = False) -> pd.DataFrame:
    """Convert VoyantFrame to pandas DataFrame.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points

    Returns:
        pandas DataFrame with named columns
    """

    if valid_only:
        data = frame.valid_points()
    else:
        data = frame.points()

    return pd.DataFrame(data, columns=frame.points_columns())


def frame_to_extended_dataframe(
    frame: VoyantFrame, valid_only: bool = False
) -> pd.DataFrame:
    """Convert VoyantFrame extended data to pandas DataFrame.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points

    Returns:
        pandas DataFrame with all extended point data columns
    """

    if valid_only:
        data = frame.valid_points_extended()
    else:
        data = frame.points_extended()

    return pd.DataFrame(data, columns=frame.points_extended_columns())


def frame_to_special_test_dataframe(
    frame: VoyantFrame, valid_only: bool = False
) -> pd.DataFrame:
    """Convert VoyantFrame special test data to pandas DataFrame.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points

    Returns:
        pandas DataFrame with special test columns (for internal systems test usage)
    """

    if valid_only:
        data = frame.valid_special_test()
    else:
        data = frame.special_test()

    return pd.DataFrame(data, columns=frame.special_test_columns())
